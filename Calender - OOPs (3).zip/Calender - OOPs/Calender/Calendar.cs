﻿
using System;
using System.Collections.Generic;
using System.Drawing;
using System.Globalization;
using System.IO;
using System.Linq;//Library required to use Where in case of Dictionary 
using System.Windows.Forms;

namespace Calender
{

    //Calendar class contains all the attributes and objects to be displayed on the window
    public partial class Calendar : Form
    {

        public int month;//Number of that Month which is currently displayed on the window
        public int year;//Year which is currently displayed on the window
        public string eventDescriptions,monthName;
        public DateTime currentDate;
        public bool setEvent=false;//Flag to check if event is saved or not
        public bool deletDone = false;//Flag to check if event is deleted or not

        public Dictionary<string, string> eventsData = new Dictionary<string, string>();



        public string path = "Events.txt";//Path of the file contating events

        public Calendar()//Constructor of Calender
        {
            InitializeComponent();

            timerForClock.Start();//Starting the Clock
            DateTime currentDateTime = DateTime.Now;
            month = currentDateTime.Month;
            year = currentDateTime.Year;

        }


        //Updating the texts of labels whose value changed recently on every tick
        private void timerForClock_Tick(object sender, EventArgs e)
        {
            DateTime dateTime = DateTime.Now;
            string date = dateTime.ToString("D");
            string AMP = dateTime.ToString("tt");
            lblTime.Text = dateTime.ToString("HH:mm:ss");
            lblDate.Text = date;
            lblAPM.Text=AMP;
            if (setEvent || deletDone)
            {
                HighlightMonthsEvents();
                setEvent = false;
                deletDone = false;
            }
            
        }


        //Highlighting the boxes of dates that have any event
        public void HighlightMonthsEvents()
        {
            string descriptions ;
            eventDescription.Text = "";
            Dictionary<string,string> displayedMonthsEvents=eventsData.Where(kvp => kvp.Key.Split(',')[0]==$"{month:00}").ToDictionary(it => it.Key, it => it.Value);//Finding all the days that lies in currently displayed month
            foreach (string key in displayedMonthsEvents.Keys)
            {

                descriptions = eventsData[key];
                string dateDay =key.Split(',')[1];

                eventDescription.Text = eventDescription.Text + $"{DateTimeFormatInfo.CurrentInfo.GetMonthName(month)} {dateDay},{descriptions}\n";

            }
        }
        private void Calendar_Load(object sender, EventArgs e)
        {

        }

        private void panel2_Paint(object sender, PaintEventArgs e)
        {


            ReadEventsData();//Reading already saved events
            DisplayCalender();//Displaying calendar with current date

        }


        //Reading Text file
        public void ReadEventsData() 
        {

            if (File.Exists(path))
            {
                using (StreamReader reader = new StreamReader(path))
                {
                    string[] lines;
                    string line = reader.ReadLine();
                    string keys, values;
                    while (line != null)
                    {
                        lines = line.Split(',');

                        keys = lines[0] + "," + lines[1];
                        values = lines[2];
                        eventsData[keys] = values;
                        line = reader.ReadLine();
                    }
                }
            }
            else//if text file does not exist create it and then closing it so that later on new events can be written
            {
                StreamWriter strm = File.CreateText(path);
                strm.Close();
            }
        }


        //Displaying calendar
        public void DisplayCalender() {
            monthName = DateTimeFormatInfo.CurrentInfo.GetMonthName(month);
            DateTime DateOfFirstDay = new DateTime(year, month, 1);//Making first day of month anobject of DateTime
            int daysInMonth = DateTime.DaysInMonth(year, month);

            int previousMonth = month != 1 ? month - 1 : 12;

            int dayOfWeek = Convert.ToInt32(DateOfFirstDay.DayOfWeek.ToString("d"));
            int previousMonthsDays = DateTime.DaysInMonth(year,previousMonth);
            int X = 0;
            int Y = 0;
            int dateDay;

            lblMonYear.Text =monthName + " " + year;



            for (int dayNumber = 0; dayNumber <42; dayNumber++)
            {
                X = dayNumber % 7 * 55;
                Y = dayNumber / 7 * 47;

                //Creating DateBoxes that do not lie in current month
                if (dayNumber < dayOfWeek  || dayNumber >= daysInMonth+dayOfWeek)
                {
                    dateDay = dayNumber >= daysInMonth+ dayOfWeek ? dayNumber - dayOfWeek - daysInMonth+1 : previousMonthsDays-dayOfWeek + dayNumber+1;
                    OtherMonthsDateBox displayDate = new OtherMonthsDateBox(this,new Point(X, Y),dateDay);//location, textForDate
                    datesTable.Controls.Add(displayDate);
                }

                //Creating DateBoxes that lie in current month
                else
                {
                    dateDay = dayNumber - dayOfWeek + 1;
                    CurrentMonthsDateBox displayDate = new CurrentMonthsDateBox(this, new Point(X, Y), dateDay);
                    
                    currentDate = new DateTime(year, month, dateDay);
                    datesTable.Controls.Add(displayDate);
                }
            }

            HighlightMonthsEvents();//Highlighting events present in a month

        }


        //Accessing Previous month
        private void GoToPreviousMonth_Click(object sender, EventArgs e)
        {
            month--;

            if (month <1)
            {
                month = 12;
                year--;
            }
            datesTable.Controls.Clear();
            DisplayCalender();
        }


        //Accessing Next month
        private void GoToNextMonth_Click(object sender, EventArgs e)
        {
            month++;
            if (month > 12){ 
                    month = 1;
                    year++;
            }
            datesTable.Controls.Clear();
            DisplayCalender();

        }


        private void panel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void eventDescription_TextChanged(object sender, EventArgs e)
        {

        }
    }
}
