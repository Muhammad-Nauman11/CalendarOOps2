﻿using System;
using System.IO;
using System.Windows.Forms;

namespace Calender
{
    public partial class EventSavingForm : Form
    {
        public CurrentMonthsDateBox dateBoxFill;
        public EventSavingForm(CurrentMonthsDateBox dateBox)
        {
            InitializeComponent();
            dateBoxFill = dateBox;
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void EventSavingForm_Load(object sender, EventArgs e)
        {
            txtDate.Text = dateBoxFill.dateOfDay + "/" + dateBoxFill.calendar.month + "/" + dateBoxFill.calendar.year;
            txtDate.ReadOnly = true;

        }

        private void btnSave_Click(object sender, EventArgs e)
        {

            string descriptions = txtEvent.Text;
            if (descriptions=="") {

                if (dateBoxFill.calendar.eventsData.ContainsKey($"{dateBoxFill.calendar.month:00},{dateBoxFill.dateOfDay:00}") && dateBoxFill.calendar.eventsData[$"{dateBoxFill.calendar.month:00},{dateBoxFill.dateOfDay:00}"] != "") {
                    dateBoxFill.calendar.deletDone = true;
                }
                dateBoxFill.calendar.eventsData.Remove($"{dateBoxFill.calendar.month:00},{dateBoxFill.dateOfDay:00}");
            }
            else
            {
                dateBoxFill.calendar.eventsData[$"{dateBoxFill.calendar.month:00},{dateBoxFill.dateOfDay:00}"] = $"{descriptions}";
                dateBoxFill.calendar.setEvent = true;
                dateBoxFill.MarkAsEvented();
            }


            using (StreamWriter file = new StreamWriter(dateBoxFill.calendar.path))
                foreach (var entry in dateBoxFill.calendar.eventsData)
                    file.WriteLine("{0},{1}", entry.Key, entry.Value);
            Close();
        }

        private void txtEvent_TextChanged(object sender, EventArgs e)
        {

        }
    }
}
