﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Calender
{
    public partial class DateBox : UserControl
    {
        public DateBox()
        {
            InitializeComponent();
        }

        private void xMonth_Click(object sender, EventArgs e)
        {

        }
        public void xDateDays(int numDay)
        {
            lblXMonth.Text = numDay + "";// Convert.ToString(numDay);
        }
    }
}
